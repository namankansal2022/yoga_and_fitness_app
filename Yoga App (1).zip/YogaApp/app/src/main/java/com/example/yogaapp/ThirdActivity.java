package com.example.yogaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    String buttonValue ;
    Button startBtn ;

    private CountDownTimer countDownTimer ;
    TextView mTextView ;
    private boolean mTimeRunning ;
    private long timeLeftInMills ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Intent intent = getIntent();
        buttonValue = intent.getStringExtra("Value");

        int intvalue = Integer.valueOf(buttonValue);

        switch(intvalue){

            case 1:
                setContentView(R.layout.activity_bow);
                break;


            case 2:
                setContentView(R.layout.activity_bridge);
                break;

            case 3:
                setContentView(R.layout.activity_chair);
                break;

            case 4:
                setContentView(R.layout.activity_child);
                break;

            case 5:
                setContentView(R.layout.activity_cobbler);
                break;


            case 6:
                setContentView(R.layout.activity_cow);
                break;


            case 7:
                setContentView(R.layout.activity_playji);
                break;



            case 8:
                setContentView(R.layout.activity_pause);
                break;


            case 9:
                setContentView(R.layout.activity_plankji);
                break;

            case 10:
                setContentView(R.layout.activity_plankrt);
                break;


            case 11:
                setContentView(R.layout.activity_plank);
                break;

            case 12:
                setContentView(R.layout.activity_bot);
                break;


            case 13:
                setContentView(R.layout.activity_howrah);
                break;


            case 14:
                setContentView(R.layout.activity_crunch);
                break;


            case 15:
                setContentView(R.layout.activity_wind);
                break;


        }


        startBtn = findViewById(R.id.startBtn);
        mTextView = findViewById(R.id.time);


        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mTimeRunning ){


                    stopTimer();


                } else {

                    startTimer();


                }
            }
        });





    }

    private void stopTimer (){


        countDownTimer.cancel();
        mTimeRunning = false ;
        startBtn.setText("START");
    }

    private void startTimer () {

        final CharSequence value1 = mTextView.getText();
        String number1 = value1.toString();
        String number2 = number1.substring(0, 2);
        String number3 = number1.substring(3, 5);

        final int number = Integer.valueOf(number2) * 60 + Integer.valueOf(number3);

        timeLeftInMills = number * 1000;

        countDownTimer = new CountDownTimer(timeLeftInMills, 1000) {
            @Override
            public void onTick(long l) {

                timeLeftInMills = l;
                updateTimer();

            }

            @Override
            public void onFinish() {

                int newValue = Integer.valueOf(buttonValue + 1);

                if(newValue <= 7){
                    Intent intent = new Intent(ThirdActivity.this , ThirdActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtra("value" ,  String.valueOf(newValue));
                    startActivity(intent);

                } else {

                    newValue = 1 ;
                    Intent intent = new Intent(ThirdActivity.this ,  ThirdActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtra("value" , String.valueOf(newValue));
                    startActivity(intent);
                }


            }
        }.start();

        startBtn.setText("Pause");
        mTimeRunning = true ;



    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void updateTimer(){

        int minutes = (int) timeLeftInMills / 60000 ;
        int seconds = (int) timeLeftInMills % 60000 / 1000 ;

        String timeLeftText = "" ;

        if (minutes > 10 )
        {
            timeLeftText = "0";
            timeLeftText = timeLeftText + minutes +":" ;

        } if (seconds<10){
            timeLeftText += "0" ;
            timeLeftText += seconds ;
            mTextView.setText(timeLeftText);
        }
    }
}