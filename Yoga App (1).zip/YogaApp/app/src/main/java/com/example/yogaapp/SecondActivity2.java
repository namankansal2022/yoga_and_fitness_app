package com.example.yogaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SecondActivity2 extends AppCompatActivity {

    int newArray [];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        newArray = new int[]{

                R.id.bow_pose,R.id.bridge_pose , R.id.chair_pose , R.id.child_pose,R.id.cobbler_pose , R.id.cow_pose ,  R.id.playji_pose, R.id.pause_pose, R.id.plankji_pose , R.id.plankrt_pose , R.id.plank_pose , R.id.bot_pose ,R.id.howrah_pose , R.id.crunch_pose , R.id.wind_pose



        };




    }

    public void ImageButtonClicked (View view)
    {

        for (int i = 0 ; i< newArray.length ; i++){

            if (view.getId() == newArray[i])
            {
                int value = i + 1 ;
                Log.i("FIRST" , String.valueOf(value));
                Intent intent = new Intent(SecondActivity2.this , ThirdActivity.class);
                intent.putExtra("Value", String.valueOf(value));
                startActivity(intent);
            }
        }


    }
}