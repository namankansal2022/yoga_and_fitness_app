package com.example.yogaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import androidx.appcompat.app.ActionBar;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {

    TextView textView;
    ImageView imageView;

    Animation up, down ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);




        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(getResources().getColor(R.color.my_statusbar_color));



//
//        ActionBar actionBar;
//        actionBar = getSupportActionBar();
//
//        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#DC0808"));
//        actionBar.setBackgroundDrawable(colorDrawable);




        textView = findViewById(R.id.app_name);



        down = AnimationUtils.loadAnimation(getApplicationContext() , R.anim.down);
        textView.setAnimation(down);



        imageView = findViewById(R.id.app_splash);


        up = AnimationUtils.loadAnimation(getApplicationContext() , R.anim.up);

        imageView.setAnimation(up);




        new Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
                Intent intent = new Intent(getApplicationContext() , MainActivity.class);
                startActivity(intent);
                finish();
            }
        },2000);
    }
}